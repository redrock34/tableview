# Build a Simple Core Data Driven iOS App

![Full Tutorial](http://www.brianadvent.com/wp-content/uploads/2017/03/moreFruits.jpg)

Read the full tutorial [here](http://www.brianadvent.com/build-simple-core-data-driven-ios-app/)
