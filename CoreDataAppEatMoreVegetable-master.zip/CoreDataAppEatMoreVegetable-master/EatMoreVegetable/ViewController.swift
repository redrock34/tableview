//
//  ViewController.swift
//  EatMoreVegetable
//
//  Created by Brian Advent on 26/02/2017.
//  Copyright © 2017 Brian Advent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDataSource {
    
    
    var table = UITableView()
    var btn = UIButton()
    
    var foodItems = [Food]()
    var moc:NSManagedObjectContext!
    var appDelegate = UIApplication.shared.delegate as? AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        moc = appDelegate?.persistentContainer.viewContext
        self.table.dataSource = self
        
        
        loadData()
        btn.backgroundColor = .systemTeal
        [table,btn].forEach{
            view.addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
        NSLayoutConstraint.activate([
            
            
            
            table.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5),
            table.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            table.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            table.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            
            btn.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5),
            btn.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            btn.topAnchor.constraint(equalTo: view.topAnchor),
            btn.leadingAnchor.constraint(equalTo: view.leadingAnchor)
            
            
            
        ])
        btn.addTarget(self, action: #selector(addFoodToDatabase(_:)), for: .touchUpInside)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        loadData()
    }
    
    func loadData(){
        // 1
        let foodRequest:NSFetchRequest<Food> = Food.fetchRequest()
        
        // 2
        let sortDescriptor = NSSortDescriptor(key: "added", ascending: false)
        foodRequest.sortDescriptors = [sortDescriptor]
        
        // 3
        do {
            try foodItems = moc.fetch(foodRequest)
            
        }catch {
            print("Could not load data")
        }
        
        // 4
        self.table.reloadData()
    }
    
    
    
    @objc   func addFoodToDatabase(_ sender: UIButton) {
        let foodItem = Food(context: moc)
        foodItem.added = NSDate() as Date
        
        
        
        appDelegate?.saveContext()
        
        loadData()
        
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foodItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        // 1
        let foodItem = foodItems[indexPath.row]
        
        // 2
        let foodType = foodItem.type
        cell.textLabel?.text = foodType
        
        // 3
        let foodDate = foodItem.added!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM d yyyy, hh:mm"
        
        cell.detailTextLabel?.text = dateFormatter.string(from: foodDate)
        
        
        
        return cell
    }
    
    
    
    
    
}

